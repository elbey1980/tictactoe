import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  title = 'tic tac toe';
  winner : String = '';
  tabJeu : String[]=[' ',' ',' ',' ',' ',' ',' ',' ',' '];
  tabReste : number[]=[0,1,2,3,4,5,6,7,8];
  tabWinner : any []= [[0, 1, 2],[3, 4, 5],[6, 7, 8],[0, 3, 6],
                       [1, 4, 7],[2, 5, 8],[0, 4, 8],[2, 4, 6] ];

  getGame() {
    var k : number;
    for (k=0; k<9;k++) this.tabJeu[k]=' ';
    this.tabReste =[0,1,2,3,4,5,6,7,8];
    this.winner = '';
  }

jouer(i : number) {
if  (this.tabJeu[i] == ' ' && this.winner=='') {
this.tour('X',i);
if (this.winner=='') this.tour('O',this.tabReste[Math.floor(Math.random() * this.tabReste.length)]);
}
}

tour(myGamer : String,  myIndex : number){
  this.tabJeu[myIndex]= myGamer;
  this.tabReste.splice(this.tabReste.indexOf(myIndex),1);
  if (this.isWinner(myGamer)) this.winner=myGamer;
}

isWinner(gamer : String): boolean {
  var j : number;
  for (j=0; j<8;j++)
     {
       if(String(this.tabJeu[this.tabWinner[j][0]]) == String(gamer)
        && String(this.tabJeu[this.tabWinner[j][1]]) == String(gamer)
        && String(this.tabJeu[this.tabWinner[j][2]]) == String(gamer)) {
        return true;
      }
    }
    return false;
  }
}
